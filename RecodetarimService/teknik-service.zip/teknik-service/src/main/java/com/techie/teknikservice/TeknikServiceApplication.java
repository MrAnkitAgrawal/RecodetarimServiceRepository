package com.techie.teknikservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeknikServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeknikServiceApplication.class, args);
	}

}
