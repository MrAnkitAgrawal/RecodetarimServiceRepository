package com.techie.teknikservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeknikServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
